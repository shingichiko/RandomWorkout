package MyRandomWorkout;

import static com.codename1.ui.CN.*;
import com.codename1.ui.Display;
import com.codename1.ui.Form;
import com.codename1.ui.Dialog;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.plaf.Style;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.util.Resources;
import com.codename1.io.Log;
import com.codename1.ui.*;
import com.codename1.ui.Toolbar;

import com.codename1.ui.layouts.BoxLayout;


/**
 * TODO add documentation
 */
public class BMICalculator {
    private Form current;
    private Resources theme;

    public void init(Object context)
    {
        theme = UIManager.initFirstTheme("/theme");

        // Enable Toolbar on all Forms by default
        Toolbar.setGlobalToolbar(true);

        // Pro only feature
        Log.bindCrashProtection(true);
    }

    public void start() {
        if (current != null) {
            current.show();
            return;
        }
        Form form = new Form("BMI calculator", BoxLayout.y());

        //Back arrow
        Style sty = UIManager.getInstance().getComponentStyle("Button");
        Image backarrow = FontImage.createMaterial(FontImage.MATERIAL_ARROW_BACK_IOS,sty);

        form.getToolbar().addCommandToLeftBar("Back",backarrow,e->{
            this.stop();
            MyRandomWorkout homePage = new MyRandomWorkout();
            homePage.start();});

        form.add(new Label("Enter your weight and height:"));

        form.add(new Label("Weight (kg):"));
        TextField weightField = new TextField("", "63.5", 10, TextArea.NUMERIC);
        form.add(weightField);

        form.add(new Label( "Height (m):"));
        TextField heightField = new TextField("", "1.72", 13, TextArea.NUMERIC);
        form.add(heightField);

        Button calculateBMI = new Button("Calculate BMI");

        calculateBMI.addActionListener((e) -> {
            Label bmiResult = new Label();
            double wgt = weightField.getAsDouble(-1);
            double hgt = heightField.getAsDouble(-1);

            double bmi = calculateBMI(wgt, hgt);
            if (bmi < 0) {
                bmiResult.setText("Invalid BMI! Enter correct height and/or weight");
            } else {
                bmiResult.setText(String.format("Your BMI is %.2f", bmi));
            }

            form.add(bmiResult);
            form.show();
        });
        form.add(calculateBMI);

        Button home = new Button("Home");
        form.add(home);
        home.addActionListener((e) -> {
            this.stop();
            MyRandomWorkout homePage = new MyRandomWorkout();
            homePage.start();
        });
        form.show();
    }

    /**
     * Calculate the BMI based on weight and height
     * @param weight in kg
     * @param height in m
     * @return the BMI or -1 if it is invalid
     */
    private double calculateBMI(double weight, double height) {
        double bmi;
        if (weight < 0 || height < 0) {
            bmi = -1.0;
        } else {
            bmi = weight/(height*height);
        }
        return bmi;
    }

    public void stop()
    {
        current = getCurrentForm();
        if(current instanceof Dialog)
        {
            ((Dialog)current).dispose();
            current = getCurrentForm();
        }
    }

    public void destroy()
    {
    }
}

