package MyRandomWorkout;

import com.codename1.io.Data;
import com.codename1.io.Log;
import com.codename1.l10n.SimpleDateFormat;
import com.codename1.ui.*;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.Style;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.spinner.Picker;
import com.codename1.ui.util.Resources;
import com.codename1.ui.validation.LengthConstraint;
import com.codename1.ui.validation.NumericConstraint;
import com.codename1.ui.validation.Validator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import static com.codename1.ui.CN.getCurrentForm;

public class CreateProfile {

    private Form current;
    private Resources theme;

    public void init(Object context)
    {
        theme = UIManager.initFirstTheme("/theme");

        // Enable Toolbar on all Forms by default
        Toolbar.setGlobalToolbar(true);

        // Pro only feature
        Log.bindCrashProtection(true);
    }

    public void start() {
        if (current != null) {
            current.show();
            return;
        }

        Form createProf = new Form("Create Profile", BoxLayout.y());
        Validator inputVal = new Validator();

        //Back arrow
        Style sty = UIManager.getInstance().getComponentStyle("Button");
        Image backarrow = FontImage.createMaterial(FontImage.MATERIAL_ARROW_BACK_IOS,sty);

        createProf.getToolbar().addCommandToLeftBar("Back",backarrow,e->{
            this.stop();
            MyRandomWorkout homePage = new MyRandomWorkout();
            homePage.start();});

        //First name and last name
        Label lblfName = new Label("First Name");
        TextComponent firstName = new TextComponent();
        inputVal.addConstraint(firstName, new LengthConstraint(1));

        Label lbllName = new Label("Last Name");
        TextComponent lastName = new TextComponent();
        inputVal.addConstraint(lastName, new LengthConstraint(1));

        Label lblDOB = new Label("Date of Birth");
        Picker dateOfBirth = new Picker();
        dateOfBirth.setType(Display.PICKER_TYPE_DATE);
        dateOfBirth.setFormatter(new SimpleDateFormat("dd/MM/yyyy"));
        Date todaysDate;
        dateOfBirth.setDate(todaysDate = new Date());
        dateOfBirth.setEndDate(new Date());


        //Gender
        Label lblgender = new Label("Gender");
        RadioButton rbM = new RadioButton("Male");
        RadioButton rbF = new RadioButton("Female");
        RadioButton rbO = new RadioButton("Other");
        //String gender;

        //Group the radio buttons
        new ButtonGroup(rbM, rbF, rbO);
        Container box = new Container(new BorderLayout());
        box.add(BorderLayout.WEST, rbM).
                add(BorderLayout.CENTER, rbF).
                add(BorderLayout.EAST, rbO);

        //Weight and height
        Label lblWeight = new Label("Weight(kg)");
        TextComponent weight = new TextComponent().errorMessage("Please Enter valid Weight");
        inputVal.addConstraint(weight, new NumericConstraint(true));

        Label lblHeight = new Label("Height(m)");
        TextComponent height = new TextComponent().errorMessage("Please Enter valid Height");
        inputVal.addConstraint(height, new NumericConstraint(true));

        Label lblGoalWeight = new Label("Goal Weight(kg)");
        TextComponent goalWeight = new TextComponent().errorMessage("Please Enter valid Weight");
        inputVal.addConstraint(goalWeight, new NumericConstraint(true));

        //Submitting the input
        Button btnsubmit = new Button("Create Profile");
        inputVal.addSubmitButtons(btnsubmit);

        createProf.addAll(lblfName,
                firstName,
                lbllName,
                lastName,
                lblDOB,
                dateOfBirth,
                lblgender,
                box,
                lblWeight,
                weight,
                lblHeight,
                height,
                lblGoalWeight,
                goalWeight,
                btnsubmit);

        btnsubmit.addActionListener((e)-> {
            Date currentDOB = dateOfBirth.getDate();
            //=============================================
            // Reference E1: externally sourced code
            // Purpose: Saving each new profile in its own file
            // Date: 28 Oct 2019
            // Source: zetcode
            // Author: N/A
            // https://www.zetcode.com/java/createfile
            // Adaptation required: Variables changed to fit into other written code and for validation
            //=============================================
            File fileIn = new File("src/" + firstName.getText() + lastName.getText() + "profile.txt");
            if (!rbF.isSelected() && !rbM.isSelected() && !rbO.isSelected()) //validate radio button options
                Dialog.show("Gender", "Please select an option", "Okay", null);
            else if(currentDOB.equals(todaysDate) || currentDOB.after(todaysDate)){
                Dialog.show("Date of birth", "Please enter a valid DOB", "Okay", null);
            } else {
                try {
                    if(fileIn.createNewFile()){
                        try(FileWriter fwtr = new FileWriter(fileIn);
                            BufferedWriter writer = new BufferedWriter(fwtr)){
                            writer.write(firstName.getText() + "\n");
                            writer.write(lastName.getText() + "\n");
                            writer.write(String.valueOf(dateOfBirth.getDate())+"\n");
                            if(rbF.isSelected() == true){
                                writer.write(rbF.getText());
                            } else if(rbM.isSelected() == true){
                                writer.write(rbM.getText());
                            } else{
                                writer.write(rbO.getText());
                            }
                            writer.write(weight.getText());
                            writer.write(height.getText());
                            writer.write(goalWeight.getText());
                            writer.close();

                        }catch (IOException err) {
                            Log.e(err);
                        }

                    } else {
                        Dialog.show("Profile","This profile already exists","Okay",null);
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                //=============================================
                // End reference E1
                //=============================================

                Dialog.show("Profile Created","Hi " + firstName.getText() + ". Your profile has been successfully created","Okay",null);
                this.stop();
            }
        });
        createProf.show();
    }


    public void stop()
    {
        current = getCurrentForm();
        if(current instanceof Dialog)
        {
            ((Dialog)current).dispose();
            current = getCurrentForm();
        }
    }

    public void destroy()
    {
    }

}
