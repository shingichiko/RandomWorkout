package MyRandomWorkout;

import static com.codename1.ui.CN.*;

import com.codename1.io.CSVParser;
import com.codename1.ui.Display;
import com.codename1.ui.Form;
import com.codename1.ui.Dialog;
import com.codename1.ui.Label;
import com.codename1.ui.geom.GeneralPath;
import com.codename1.ui.geom.Rectangle;
import com.codename1.ui.layouts.*;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.Style;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.util.Resources;
import com.codename1.io.Log;
import com.codename1.ui.*;
import com.codename1.ui.Toolbar;

import java.io.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.ArrayList;

import com.codename1.io.NetworkEvent;

import javax.imageio.ImageIO;
import javax.swing.*;

public class PreviousWorkouts {

    private Form current;
    private Resources theme;

    public void init(Object context)
    {
        theme = UIManager.initFirstTheme("/theme");

        // Enable Toolbar on all Forms by default
        Toolbar.setGlobalToolbar(true);

        // Pro only feature
        Log.bindCrashProtection(true);
    }

    public void start() {
        if (current != null) {
            current.show();
            return;
        }
        Form hi = new Form("My Random Workout", BoxLayout.y());

        //Back arrow
        Style sty = UIManager.getInstance().getComponentStyle("Button");
        Image backarrow = FontImage.createMaterial(FontImage.MATERIAL_ARROW_BACK_IOS,sty);

        hi.getToolbar().addCommandToLeftBar("Back",backarrow,e->{
            this.stop();
            MyRandomWorkout homePage = new MyRandomWorkout();
            homePage.start();});

        int count = 1;
        String line;
        File fPreviousWorkoutsLoopCheck = new File("src/MyRandomWorkout/PreviousWorkouts/WorkoutExercises1.csv");

        //=============================================
        // Reference D1: externally sourced code
        // Purpose: To read a file
        // Date: 20 Oct 2019
        // Source: DreamInCode
        // Author: (Username:) dragon-slayer
        // https://www.dreamincode.net/forums/topic/27972-reading-and-writing-to-a-file-in-java/
        // Adaptation required: Values and variables changed to suit specifications, put into a loop to read several files upon request
        //=============================================
            if (fPreviousWorkoutsLoopCheck.exists())
            {
                File fPreviousWorkouts = (fPreviousWorkoutsLoopCheck);
                while (fPreviousWorkouts.exists())
                {
                    fPreviousWorkouts = new File("src/MyRandomWorkout/PreviousWorkouts/WorkoutExercises" + count + ".csv");
                    try (BufferedReader readFile = new BufferedReader(new FileReader("src/MyRandomWorkout/PreviousWorkouts/WorkoutExercises" + count + ".csv")))
                    {
                        hi.add(new Label("Workout " + count + ""));
                        hi.add(new Label("-----------------"));
                        while ((line = readFile.readLine()) != null)
                        {
                            hi.add(new Label(line));
                        }
                        readFile.close();
                        hi.add(new Label("\n-----------------\n"));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    count++;
                    fPreviousWorkouts = new File("src/MyRandomWorkout/PreviousWorkouts/WorkoutExercises" + count + ".csv");
                }
            }

        //=============================================
        // End reference D1
        //=============================================

        // code to add a back button
        Button home = new Button("Home");
        hi.add(home);
        home.addActionListener((e) -> {
            this.stop();
            MyRandomWorkout homePage = new MyRandomWorkout();
            homePage.start();
        });
        // code to add a back button ends

        hi.show();
    }

    public void stop()
    {
        current = getCurrentForm();
        if(current instanceof Dialog)
        {
            ((Dialog)current).dispose();
            current = getCurrentForm();
        }
    }

    public void destroy()
    {
    }
}
