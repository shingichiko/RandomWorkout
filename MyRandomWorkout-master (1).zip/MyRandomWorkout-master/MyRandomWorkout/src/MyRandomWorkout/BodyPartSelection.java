package MyRandomWorkout;

import static com.codename1.ui.CN.*;
import com.codename1.ui.Display;
import com.codename1.ui.Form;
import com.codename1.ui.Dialog;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.plaf.Style;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.util.Resources;
import com.codename1.io.Log;
import com.codename1.ui.*;
import com.codename1.ui.Toolbar;
import java.io.IOException;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.io.NetworkEvent;
import javax.swing.*;

public class BodyPartSelection {
    private Form current;
    private Resources theme;

    public void init(Object context)
    {
        theme = UIManager.initFirstTheme("/theme");

        // Enable Toolbar on all Forms by default
        Toolbar.setGlobalToolbar(true);

        // Pro only feature
        Log.bindCrashProtection(true);
    }

    public void start() {
        if (current != null) {
            current.show();
            return;
        }
        Form form = new Form("My Random Workout", BoxLayout.y());

        //Back arrow
        Style sty = UIManager.getInstance().getComponentStyle("Button");
        Image backarrow = FontImage.createMaterial(FontImage.MATERIAL_ARROW_BACK_IOS,sty);

        form.getToolbar().addCommandToLeftBar("Back",backarrow,e->{
            this.stop();
            MyRandomWorkout homePage = new MyRandomWorkout();
            homePage.start();});


        form.add(new Label("Please select the body parts you wish to train:"));

        //Adds checkboxes for each body part the user can select
        CheckBox cbx_Arms = new CheckBox("Arms");
        form.add(cbx_Arms);

        CheckBox cbx_Legs = new CheckBox("Legs");
        form.add(cbx_Legs);

        CheckBox cbx_Chest = new CheckBox("Chest");
        form.add(cbx_Chest);

        CheckBox cbx_Back = new CheckBox("Back");
        form.add(cbx_Back);

        CheckBox cbx_Abs = new CheckBox("Abs");
        form.add(cbx_Abs);

        CheckBox cbx_Shoulders = new CheckBox("Shoulders");
        form.add(cbx_Shoulders);

        // When WholeBody checkbox is selected all body parts and selected and when it is unselected it unselects the body parts
        CheckBox cbx_WholeBody = new CheckBox("Whole Body");
        form.add(cbx_WholeBody);
        cbx_WholeBody.addChangeListener((e) -> {
            if(cbx_WholeBody.isSelected() == true)
            {
                cbx_Arms.setSelected(true);
                cbx_Legs.setSelected(true);
                cbx_Chest.setSelected(true);
                cbx_Back.setSelected(true);
                cbx_Abs.setSelected(true);
                cbx_Shoulders.setSelected(true);
            }
            else
            {
                cbx_Arms.setSelected(false);
                cbx_Legs.setSelected(false);
                cbx_Chest.setSelected(false);
                cbx_Back.setSelected(false);
                cbx_Abs.setSelected(false);
                cbx_Shoulders.setSelected(false);
            }
        });

        //Finds out how many exercises the user whichs to do
        form.add(new Label("How many exercises would you like:"));

        TextField noExercises = new TextField("", "10", 20, TextArea.NUMERIC);
        form.add(noExercises);

        //Once the user selects the finish button the body parts selected and number of exercises is sent to Workout Generator
        Button btn_Finish = new Button("Finish");
        btn_Finish.addActionListener((e) -> {
            if(Integer.parseInt(noExercises.getText()) > 0) {
                if(cbx_Arms.isSelected() || cbx_Legs.isSelected() || cbx_Chest.isSelected() || cbx_Back.isSelected() || cbx_Abs.isSelected() || cbx_Shoulders.isSelected()) {
                    WorkoutGenerator workoutGenerator = new WorkoutGenerator();
                    workoutGenerator.start(cbx_Arms.isSelected(), cbx_Legs.isSelected(), cbx_Chest.isSelected(), cbx_Back.isSelected(), cbx_Abs.isSelected(), cbx_Shoulders.isSelected(), cbx_WholeBody.isSelected(), Integer.parseInt(noExercises.getText()));
                    workoutGenerator.stop();
                }
            }
        });
        form.add(btn_Finish);

        // code to add a back button
        Button home = new Button("Home");
        form.add(home);
        home.addActionListener((e) -> {
            this.stop();
            MyRandomWorkout homePage = new MyRandomWorkout();
            homePage.start();
        });
        // code to add a back button ends

        form.show();
    }

    public void stop()
    {
        current = getCurrentForm();
        if(current instanceof Dialog)
        {
            ((Dialog)current).dispose();
            current = getCurrentForm();
        }
    }

    public void destroy()
    {
    }
}
