package MyRandomWorkout;

import static com.codename1.ui.CN.*;

import com.codename1.ui.Display;
import com.codename1.ui.Form;
import com.codename1.ui.Dialog;
import com.codename1.ui.Label;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.layouts.*;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.table.*;
import com.codename1.ui.util.Resources;
import com.codename1.io.Log;
import com.codename1.ui.*;
import com.codename1.ui.Toolbar;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.io.FileWriter;

import com.codename1.io.CSVParser;
import javax.swing.*;

public class WorkoutGenerator {
    private Form current;
    private Resources theme;
    Container container;

    public void init(Object context)
    {
        theme = UIManager.initFirstTheme("/theme");

        // Enable Toolbar on all Forms by default
        Toolbar.setGlobalToolbar(true);

        // Pro only feature
        Log.bindCrashProtection(true);
    }

    public void start(boolean Arms, boolean Legs, boolean Chest, boolean Back, boolean Abs, boolean Shoulders, boolean WholeBody, int NoExercises) {
        if (current != null) {
            current.show();
            return;
        }

        GridBagLayout gbl = new GridBagLayout();

        Form hi = new Form("My Random Workout", gbl);

        String csvFile = "src/MyRandomWorkout/WorkoutExercises.csv";

        CSVParser parser = new CSVParser();
        try(Reader r = new FileReader(csvFile)) {
            String[][] csvWorkoutdata = parser.parse(r);
            String[] csvFilteredWorkout = new String[csvWorkoutdata.length];

            int filteredCount = 0;

            // Loops through the csv file and if the selected body part is selected then it is added to a new array which will be used to generate the workout
            for(int row = 0; row < csvWorkoutdata.length; row++){
                if(Arms) {
                    if(csvWorkoutdata[row][1].equals("Arms")) {
                        csvFilteredWorkout[filteredCount] = csvWorkoutdata[row][0];
                        filteredCount++;
                    }
                }
                if(Legs) {
                    if(csvWorkoutdata[row][1].equals("Legs")) {
                        csvFilteredWorkout[filteredCount] = csvWorkoutdata[row][0];
                        filteredCount++;
                    }
                }
                if(Chest) {
                    if(csvWorkoutdata[row][1].equals("Chest")) {
                        csvFilteredWorkout[filteredCount] = csvWorkoutdata[row][0];
                        filteredCount++;
                    }
                }
                if(Back) {
                    if(csvWorkoutdata[row][1].equals("Back")) {
                        csvFilteredWorkout[filteredCount] = csvWorkoutdata[row][0];
                        filteredCount++;
                    }
                }
                if(Abs) {
                    if(csvWorkoutdata[row][1].equals("Abs")) {
                        csvFilteredWorkout[filteredCount] = csvWorkoutdata[row][0];
                        filteredCount++;
                    }
                }
                if(Shoulders) {
                    if(csvWorkoutdata[row][1].equals("Shoulders")) {
                        csvFilteredWorkout[filteredCount] = csvWorkoutdata[row][0];
                        filteredCount++;
                    }
                }
            }

            //determines the length of the new array
            int arrayLength = 0;
            String[] outputData = new String[100];
            for(int i = 0; i < csvFilteredWorkout.length; i ++)
            {
                if(csvFilteredWorkout[i] != null)
                {
                    outputData[i] = csvFilteredWorkout[i];
                    arrayLength++;
                }


            }

            //
            //=============================================
            // Reference C1: externally sourced code
            // Purpose: Creates a new list with the amount of exercises that are left to select from then shuffles the list so it gets a random work every time
            // Date: 16 Oct 2019
            // Source: stackoverflow
            // Author: Andrew Thompson
            // https://stackoverflow.com/questions/8115722/generating-unique-random-numbers-in-java
            // Adaptation required: changed variable names and design of function that was supplied
            //=============================================

            List<Integer> numList = new ArrayList<Integer>();
            for (int i = 0; i < arrayLength; i++) {
                numList.add(i);
            }

            Collections.shuffle(numList);

            //=============================================
            // End reference C5
            //=============================================

            hi.setLayout(gbl);
            GridBagConstraints c = new GridBagConstraints();

            for (int i = 0; i < NoExercises; i++){
                Label exerciseLbl = new Label(csvFilteredWorkout[numList.get(i)]);
                TextField repTxtFld = new TextField("10", "", 4, TextArea.NUMERIC);
                Label repLbl = new Label("reps");

                c.weightx = 0.8;
                c.fill = GridBagConstraints.HORIZONTAL;
                c.gridx = 0;
                c.gridy = i;
                hi.addComponent(c, exerciseLbl);

                c.weightx = 0.5;
                c.fill = GridBagConstraints.HORIZONTAL;
                c.gridx = 2;
                c.gridy = i;
                hi.addComponent(c, repTxtFld);

                c.weightx = 0.2;
                c.fill = GridBagConstraints.HORIZONTAL;
                c.gridx = 3;
                c.gridy = i;
                hi.addComponent(c, repLbl);
            }

            Button btnFinish = new Button("Finish");
            btnFinish.addActionListener((e) -> {
                MyRandomWorkout myRandomWorkout = new MyRandomWorkout();
                myRandomWorkout.start();
            });

            c.gridwidth = 100;
            c.gridx = 0;
            c.gridy = 4;
            hi.addComponent(c, btnFinish);


            // Sends generated Workout to a new .csv for PreviousWorkouts.java to access them.

            File fPreviousWorkouts = new File("src/MyRandomWorkout/PreviousWorkouts/WorkoutExercises1.csv");
            int count = 1;
            // ensures that the file is created if non-existent
            if (!fPreviousWorkouts.exists())
            {
                fPreviousWorkouts.createNewFile();
            }
            else
            {
                // Creates files with new name if it already exists
                while (fPreviousWorkouts.exists())
                {
                    fPreviousWorkouts = new File("src/MyRandomWorkout/PreviousWorkouts/WorkoutExercises"+count+".csv");
                    count++;
                }
            }
            FileWriter fwPreviousWorkouts = new FileWriter(fPreviousWorkouts);
            BufferedWriter out = new BufferedWriter(fwPreviousWorkouts);

            for (int i = 0; i < NoExercises; i++)
            {
                out.write(outputData[i] + "\n");
            }

            out.close();

        } catch(IOException err) {
            Log.e(err);
        }
        hi.show();
    }

    public void stop()
    {
        current = getCurrentForm();
        if(current instanceof Dialog)
        {
            ((Dialog)current).dispose();
            current = getCurrentForm();
        }
    }

    public void destroy()
    {
    }
}